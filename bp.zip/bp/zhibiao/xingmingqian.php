<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>姓名签-棋类比赛抽签：姓名签</title>


<link href="/bp/css/shuchu.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
}
.biaoti{
	font-family:"黑体";
	font-size:26px;
    
}
a,td,th{
    height: 26px;
	font-size: 18px;
	text-align: center;
}

-->
</style>

</head>

<body>



<table border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="328px">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<th colspan="5">
			  <div align="center" style=" margin:6px">
			       棋类比赛抽签：姓名签<br />
					 <div align="left" style="margin-top:6px">
					     单位：&nbsp;&nbsp; &nbsp;&nbsp;姓名：&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;序号：			    </div>
		      </div>
			</th>
		  </tr>
		  <tr>
			<td colspan="5">
               <table width="100%" border="1" cellspacing="0" cellpadding="0">
				   <tr>
					<th width="56">
						轮次					</th>
					<th width="80">对手</th>
					<th width="66">先后</th>
					<th width="66">积分</th>
					<th width="66">对手分</th>
				  </tr>
				  <tr>
					<td>1</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				  </tr>
				  <tr>
				    <td>2</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>3</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>4</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>5</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>6</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>7</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>8</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>9</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>10</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>11</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
			   </table>
			</td>
		  </tr>
          <tr>
			  <td>
			  <div align="left" style="margin:6px;">
			     组别：
			  </div>
			  </td>
		  </tr>
	  </table>
	</td>
    <td width="4px">&nbsp;</td>
    <td width="328px">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<th colspan="5">
			  <div align="center" style=" margin:6px">
			       棋类比赛抽签：姓名签<br />
					 <div align="left" style="margin-top:6px">
					     单位：&nbsp;&nbsp; &nbsp;&nbsp;姓名：&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;序号：			    </div>
		      </div>
			</th>
		  </tr>
		  <tr>
			<td colspan="5">
               <table width="100%" border="1" cellspacing="0" cellpadding="0">
				   <tr>
					<th width="56">
						轮次					</th>
					<th width="80">对手</th>
					<th width="66">先后</th>
					<th width="66">积分</th>
					<th width="66">对手分</th>
				  </tr>
				  <tr>
					<td>1</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				  </tr>
				  <tr>
				    <td>2</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>3</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>4</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>5</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>6</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>7</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>8</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>9</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>10</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>11</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
			   </table>
			</td>
		  </tr>
          <tr>
			  <td>
			  <div align="left" style="margin:6px;">
			     组别：
			  </div>
			  </td>
		  </tr>
	  </table>
	</td>
  </tr>

  
  <tr>
    <td colspan="3" height="36px">
	<hr />
	</td>
  </tr>
  
  <tr>
    <td width="328px">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<th colspan="5">
			  <div align="center" style=" margin:6px">
			       棋类比赛抽签：姓名签<br />
					 <div align="left" style="margin-top:6px">
					     单位：&nbsp;&nbsp; &nbsp;&nbsp;姓名：&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;序号：			    </div>
		      </div>
			</th>
		  </tr>
		  <tr>
			<td colspan="5">
               <table width="100%" border="1" cellspacing="0" cellpadding="0">
				   <tr>
					<th width="56">
						轮次					</th>
					<th width="80">对手</th>
					<th width="66">先后</th>
					<th width="66">积分</th>
					<th width="66">对手分</th>
				  </tr>
				  <tr>
					<td>1</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				  </tr>
				  <tr>
				    <td>2</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>3</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>4</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>5</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>6</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>7</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>8</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>9</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>10</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>11</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
			   </table>
			</td>
		  </tr>
          <tr>
			  <td>
			  <div align="left" style="margin:6px;">
			     组别：
			  </div>
			  </td>
		  </tr>
	  </table>
	</td>
    <td width="4px">&nbsp;</td>
    <td width="328px">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		  <tr>
			<th colspan="5">
			  <div align="center" style=" margin:6px">
			       棋类比赛抽签：姓名签<br />
					 <div align="left" style="margin-top:6px">
					     单位：&nbsp;&nbsp; &nbsp;&nbsp;姓名：&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;序号：			    </div>
		      </div>
			</th>
		  </tr>
		  <tr>
			<td colspan="5">
               <table width="100%" border="1" cellspacing="0" cellpadding="0">
				   <tr>
					<th width="56">
						轮次					</th>
					<th width="80">对手</th>
					<th width="66">先后</th>
					<th width="66">积分</th>
					<th width="66">对手分</th>
				  </tr>
				  <tr>
					<td>1</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				  </tr>
				  <tr>
				    <td>2</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>3</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>4</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>5</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>6</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>7</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>8</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>9</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>10</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
				  <tr>
				    <td>11</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
				    <td>&nbsp;</td>
			     </tr>
			   </table>
			</td>
		  </tr>
          <tr>
			  <td>
			  <div align="left" style="margin:6px;">
			     组别：
			  </div>
			  </td>
		  </tr>
	  </table>
	</td>
  </tr>
  
</table>



</body>
</html>
