<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>个人成绩(简表)</title>

<link href="/bp/css/shuchu.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	text-align:center;
}
.biaoti{
	font-family:"黑体";
	font-size:26px;
    
}
.grzfzTTCJ {
    width:660px;
	text-align:center;
}
a,td,th,input,select {
    height:26px;
	font-size: 20px;
	text-align: center;
	padding:6px 0 0 0;
}

-->
</style>


</head>

<body>
<!--个人成绩(简表)-->

<table border="0" cellspacing="0">
	<tr>
		<td>

			<table style="grzfzTTCJ" width="660px" border="1" cellspacing="0" cellpadding="0">
			  <tr>
				<td colspan="8" valign="middle" height="70px">
					<div style="font-family:'黑体';font-size:26px;text-align:center;">
						个人成绩(简表)<br />
						<div align="right" style="margin:6px;font-family:'宋体';font-size:12px;">
							 《发的附件二姐夫东方金额》-男子组&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;						</div>
					</div>			    </td>
			  </tr>
			  <tr>
				<th width="30" >组别</th>
				<th width="90">名次</th>
				<th width="auto">单位</th>
				<th width="auto">姓名</th>
				<th width="60">总分</th>
				<th width="80">对手分<br />
				  累进分</th>
				<th width="60">胜局</th>
				<th width="110">备注</th>
			  </tr>
			  <tr>
				<td rowspan="8" width="30px">
			    <strong>男子组</strong> </td>
				<td >第一名 </td>
				<td >门头沟区 </td>
				<td >大大富大贵</td>
				<td >4 </td>
				<td >&nbsp;</td>
				<td >&nbsp;</td>
				<td >&nbsp;</td>
			  </tr>
			  <tr>
				<td >第二名 </td>
				<td >朝阳区 </td>
				<td >&nbsp;</td>
				<td >10 </td>
				<td >&nbsp;</td>
				<td >&nbsp;</td>
				<td >&nbsp;</td>
			  </tr>
			  <tr>
				<td >第三名 </td>
				<td >昌平区 </td>
				<td >&nbsp;</td>
				<td >12 </td>
				<td >&nbsp;</td>
				<td >&nbsp;</td>
				<td >&nbsp;</td>
			  </tr>
			  <tr>
				<td >第四名 </td>
				<td >海淀区 </td>
				<td >&nbsp;</td>
				<td >19 </td>
				<td >&nbsp;</td>
				<td >&nbsp;</td>
				<td >&nbsp;</td>
			  </tr>
			  <tr>
				<td >第五名 </td>
				<td >顺义区 </td>
				<td >&nbsp;</td>
				<td >24 </td>
				<td >5 </td>
				<td >&nbsp;</td>
				<td >&nbsp;</td>
			  </tr>
			  <tr>
				<td >第六名 </td>
				<td >房山区 </td>
				<td >&nbsp;</td>
				<td >24 </td>
				<td >7</td>
				<td >&nbsp;</td>
				<td >&nbsp;</td>
			  </tr>
			  <tr>
				<td >第七名 </td>
				<td >怀柔区 </td>
				<td >&nbsp;</td>
				<td >32 </td>
				<td >12 </td>
				<td >&nbsp;</td>
				<td >&nbsp;</td>
			  </tr>
			  <tr>
				<td >第八名 </td>
				<td >通州区 </td>
				<td >&nbsp;</td>
				<td >32 </td>
				<td >14 </td>
				<td >&nbsp;</td>
				<td >&nbsp;</td>
			  </tr>
			  <tr>
				<td rowspan="4" width="30">
			    <strong>女子组</strong> </td>
				<td>第一名 </td>
				<td>门头沟区 </td>
				<td>&nbsp;</td>
				<td>7 </td>
				<td>2 </td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			  </tr>
			  <tr>
				<td>第二名 </td>
				<td>朝阳区 </td>
				<td>&nbsp;</td>
				<td>7 </td>
				<td>3 </td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			  </tr>
			  <tr>
				<td>第三名 </td>
				<td>昌平区 </td>
				<td>&nbsp;</td>
				<td>8 </td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			  </tr>
			  <tr>
				<td>第四名 </td>
				<td>延庆县 </td>
				<td>&nbsp;</td>
				<td>14 </td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			  </tr>
			</table>

		</td>
	</tr>
	<tr>
		<td colspan="5" height="5px">
		</td>
	</tr>
	<tr>
		<td>
		<div align="left">裁判长：   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;编排员：&nbsp;&nbsp;&nbsp;</div>
		<div align="right">&nbsp;&nbsp;&nbsp;年&nbsp;&nbsp;&nbsp;月&nbsp;&nbsp;&nbsp;日</div>
		</td>
	</tr>
</table>



</body>
</html>
