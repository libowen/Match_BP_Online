<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>无标题文档</title>
</head>

<body>
<p align="left"><strong>成绩单</strong> <br />
    <strong>组别：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  日期：&nbsp;&nbsp; 年&nbsp;&nbsp; 月&nbsp;&nbsp; 日</strong> </p>
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="71"><br />
        <strong>台次</strong> </td>
    <td width="56"><p align="center"><strong>序号</strong> </p></td>
    <td width="86"><p align="center"><strong>姓名</strong> </p></td>
    <td width="71"><p align="center"><strong>先后</strong> </p></td>
    <td width="71"><p align="center"><strong>成绩</strong> </p></td>
    <td width="71"><p align="center"><strong>用时</strong> </p></td>
    <td width="71"><p align="center"><strong>犯规</strong> </p></td>
    <td width="71"><p align="center"><strong>备注</strong> </p></td>
  </tr>
  <tr>
    <td width="71" rowspan="2" valign="top"><p align="left">&nbsp;</p></td>
    <td width="56" valign="top"><p align="left">&nbsp;</p></td>
    <td width="86" valign="top"><p align="left">&nbsp;</p></td>
    <td width="71" valign="top"><p align="left">&nbsp;</p></td>
    <td width="71" valign="top"><p align="left">&nbsp;</p></td>
    <td width="71" valign="top"><p align="left">&nbsp;</p></td>
    <td width="71" valign="top"><p align="left">&nbsp;</p></td>
    <td width="71" valign="top"><p align="left">&nbsp;</p></td>
  </tr>
  <tr>
    <td width="56" valign="top"><p align="left">&nbsp;</p></td>
    <td width="86" valign="top"><p align="left">&nbsp;</p></td>
    <td width="71" valign="top"><p align="left">&nbsp;</p></td>
    <td width="71" valign="top"><p align="left">&nbsp;</p></td>
    <td width="71" valign="top"><p align="left">&nbsp;</p></td>
    <td width="71" valign="top"><p align="left">&nbsp;</p></td>
    <td width="71" valign="top"><p align="left">&nbsp;</p></td>
  </tr>
</table>
<p align="left"><strong>签字：红方：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 黑方：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 裁判员：</strong> </p>
</body>
</html>
