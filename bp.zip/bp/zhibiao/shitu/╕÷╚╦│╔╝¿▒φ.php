<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>无标题文档</title>
</head>

<body>
<div align="center">
  <table width="800" border="0" align="center">
    <tr>
      <td colspan="2" class="biaoti">07年广西高校第二届象棋锦标赛成绩表</td>
    </tr>
    <tr height="4">
      <td></td>
      <td></td>
    </tr>
    <tr class="shuoming">
      <td><div align="left">组别：男子A组</div></td>
      <td><div align="right">第1页（共3页）</div></td>
    </tr>
    <tr class="shuoming">
      <td><div align="left">比赛地点：广西大学</div></td>
      <td><div align="right">比赛时间：2007年10月27-28日</div></td>
    </tr>
    <tr height="2">
      <td></td>
      <td></td>
    </tr>
  </table>
  <table border="1" align="center" class="xxchengji">
    <tr>
      <td rowspan="2" width="20"><span class="font14">编号</span></td>
      <td rowspan="2" width="80"><span class="font14">单位</span></td>
      <td rowspan="2" width="80"><span class="font14">姓名</span></td>
      <td colspan="2" width="auto">第一轮</td>
      <td colspan="2" width="auto">第二轮</td>
      <td colspan="2" width="auto">第三轮</td>
      <td colspan="2" width="auto">第四轮</td>
      <td colspan="2" width="auto">第五轮</td>
      <td rowspan="2" width="40"><span class="font14 font14">积分</span></td>
      <td rowspan="2" width="42"><span class="font14">累进分</span></td>
      <td rowspan="2" width="20"><span class="font14">犯规</span></td>
      <td rowspan="2" width="36"><span class="font14">名次</span></td>
    </tr>
    <tr>
      <td>对手</td>
      <td>积分</td>
      <td>对手</td>
      <td>积分</td>
      <td>对手</td>
      <td>积分</td>
      <td>对手</td>
      <td>积分</td>
      <td>对手</td>
      <td>积分</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>的方法东风</td>
      <td>反对发的</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
  <table width="800" border="0" align="center" class="beizhu">
    <tr height="3">
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td>裁判长：何等的</td>
      <td>软件编排：的哦体贴</td>
      <td>打印时间：2007年10月27日 19:23:22</td>
    </tr>
  </table>
</div>
</body>
</html>
