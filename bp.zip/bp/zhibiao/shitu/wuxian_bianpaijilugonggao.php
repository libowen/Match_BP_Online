<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>编排纪录公告（对阵表）无线的</title>


<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
}
/*编排的界面*/
.Lbianpai{
    font-family:"黑体";
    width: 660px;
}
.Lbianpai tr:hover {
    background-color:#FFFF99;
}
.Lbianpai td,th {
	font-size: 18px;
	text-align: center;
}
.nei td,th{
    height:30px;
}

-->
</style>

</head>

<body>

<!--编排纪录公告（对阵表）；同时可作为本轮的成绩显示表，字体大小最小20px，最大28px；
20px时一页A4纸容入恰好27台（和裁判）；
22px时一页A4纸容入恰好24-25台（和裁判）；
24px时一页A4纸容入恰好22-23台（和裁判）；
26px时一页A4纸容入恰好20台（和裁判）；A4纸内容高790px以上
28px时，刚好19台和裁判；
需去掉链接
-->
<table class="Lbianpai" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="3" height="5px"></td>
  </tr>
  <tr>
    <td colspan="3" style="font-size:24px;font-weight:bold">
	<div>
	2009年广西中国象棋锦标赛（成人组）<br />
	</div>
	<div style="margin:3px;">
	第9台 台数编排表
	</div>
	</td>
  </tr>
  <tr>
    <td colspan="3" height="2px"></td>
  </tr>
  <tr>
    <td width="34%"><div align="left">组别： 成人组</div></td>
    <td width="33%">&nbsp;</td>
    <td width="33%"><div align="right">第1页（共3页）</div>
	</td>
  </tr>
  <tr>
	  <td colspan="3" height="5px">
	     <hr />
	  </td>
  </tr>
  <tr>
    <td colspan="3"> 
		<table class="nei" border="0" align="center" width="660px" cellspacing="0"><!--编排结果显示区域-->
		  <tbody>
			<tr>
			  <th scope="col" height="30px">&nbsp;</th>
			  <th scope="col" colspan="4">红方</th>
			  <th scope="col">&nbsp;</th>
			  <th scope="col" colspan="4">黑方</th>
			</tr>
			<tr>
			  <td width="45px" height="28px">台次</td>
			  <td width="92px">单位</td>
			  <td width="92px">姓名</td>
			  <td width="46px">积分</td>
			  <td width="46px">序号</td>
			  
			  <td width="auto">胜负</td>
			  
			  <td width="46px">序号</td>
			  <td width="46px">积分</td>
			  <td width="92px">单位</td>
			  <td width="92px">姓名</td>
			</tr>
			<tr>
			  <td>[55]</td>
			  <td>8</td>
			  <td>第八件</td>
			  <td>125</td>
			  <td>11</td>
			  <td>0.5:0.5 </td>
			  <td>&nbsp;</td>
			  <td>1</td>
			  <td>单位单位</td>
			  <td>第一选14</td>
			</tr>
			<tr>
			  <td>[2]</td>
			  <td>单位单位fd</td>
			  <td>得第三选手</td>
			  <td>58.2</td>
			  <td>160</td>
			  <td>3:2 </td>
			  <td></td>
			  <td>12.5</td>
			  <td>单位单位</td>
			  <td>1大幅度</td>
			</tr>
			<tr>
			  <td>[6]</td>
			  <td>单位单位</td>
			  <td>第17个</td>
			  <td>&nbsp;</td>
			  <td>10</td>
			  <td>: </td>
			  <td>&nbsp;</td>
			  <td>36.9</td>
			  <td>十六格</td>
			  <td>大股东</td>
			</tr>
			<tr>
			  <td>[55]</td>
			  <td>单位单位</td>
			  <td>字26名</td>
			  <td>&nbsp;</td>
			  <td>9</td>
			  <td>: </td>
			  <td>&nbsp;</td>
			  <td>10</td>
			  <td>第十的</td>
			  <td>大幅度</td>
			</tr>
			<tr>
			  <td>[5]</td>
			  <td>单位单位</td>
			  <td>第21姓</td>
			  <td>&nbsp;</td>
			  <td>9</td>
			  <td>: </td>
			  <td>&nbsp;</td>
			  <td>20</td>
			  <td>么20名i</td>
			  <td>大幅度</td>
			</tr>
			<tr>
			  <td>[6]</td>
			  <td>单位单位</td>
			  <td>地24姓</td>
			  <td>&nbsp;</td>
			  <td>8</td>
			  <td>: </td>
			  <td>&nbsp;</td>
			  <td>22</td>
			  <td>字22好</td>
			  <td>犯规发货</td>
			</tr>
			<tr>
			  <td>[567]</td>
			  <td>7</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>单位单位</td>
			  <td>&nbsp;</td>
		    </tr>
			<tr>
			  <td>&nbsp;</td>
			  <td>8</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
		    </tr>
			<tr>
			  <td>&nbsp;</td>
			  <td>9</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
		    </tr>
			<tr>
			  <td>&nbsp;</td>
			  <td>10</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
		    </tr>
			<tr>
			  <td>&nbsp;</td>
			  <td>11</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
		    </tr>
			<tr>
			  <td>&nbsp;</td>
			  <td>12</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
		    </tr>
			<tr>
			  <td>&nbsp;</td>
			  <td>13</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
		    </tr>
			<tr>
			  <td>&nbsp;</td>
			  <td>14</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
		    </tr>
			<tr>
			  <td>&nbsp;</td>
			  <td>15</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
		    </tr>
			<tr>
			  <td>&nbsp;</td>
			  <td>16</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
		    </tr>
			<tr>
			  <td>&nbsp;</td>
			  <td>17</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
		    </tr>
			<tr>
			  <td>&nbsp;</td>
			  <td>18</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
		    </tr>
			<tr>
			  <td>&nbsp;</td>
			  <td>19</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
		    </tr>
			<tr>
			  <td>[67]</td>
			  <td>大富大贵</td>
			  <td>大幅降低</td>
			  <td>35</td>
			  <td>6</td>
			  <td>&nbsp;</td>
			  <td>6</td>
			  <td>35</td>
			  <td>刚发给的</td>
			  <td>非官方饿</td>
		    </tr>
		  </tbody>
		</table> 
		<!--编排结果显示区域-->	</td>
  </tr>
  <!--编排结果显示区域-->
  <tr>
	  <td colspan="3" height="3px">
	     <hr />
	  </td>
  </tr>
  <tr>
    <td>
	    <div align="left">裁判长：</div>
	</td>
	<td>
	     <div align="left">编排：</div>
	</td>
	<td>
	     <div align="left">软件编排：</div>
	</td>
  </tr>
</table>

</body>
</html>
