<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>无标题文档</title>
</head>

<body>
<p align="center"><strong>象棋赛团体成绩</strong> </p>
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="55" valign="top"><p align="center"><strong>组别</strong> </p></td>
    <td width="108"><p align="center"><strong>名次</strong> </p></td>
    <td width="132"><p align="center"><strong>单位</strong> </p></td>
    <td width="96"><p align="center"><strong>名次分</strong> </p></td>
    <td width="177"><p align="center"><strong>最高个人名次</strong> </p></td>
  </tr>
  <tr>
    <td width="55" rowspan="8"><p align="center"><strong>男</strong> <br />
            <strong>子</strong> <br />
            <strong>组</strong> </p></td>
    <td width="108" valign="top"><p align="center">第一名 </p></td>
    <td width="132" valign="top"><p align="center">门头沟区 </p></td>
    <td width="96" valign="top"><p align="center">4 </p></td>
    <td width="177" valign="top"><p align="center">&nbsp;</p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第二名 </p></td>
    <td width="132" valign="top"><p align="center">朝阳区 </p></td>
    <td width="96" valign="top"><p align="center">10 </p></td>
    <td width="177" valign="top"><p align="center"><strong>&nbsp;</strong> </p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第三名 </p></td>
    <td width="132" valign="top"><p align="center">昌平区 </p></td>
    <td width="96" valign="top"><p align="center">12 </p></td>
    <td width="177" valign="top"><p align="center">&nbsp;</p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第四名 </p></td>
    <td width="132" valign="top"><p align="center">海淀区 </p></td>
    <td width="96" valign="top"><p align="center">19 </p></td>
    <td width="177" valign="top"><p align="center">&nbsp;</p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第五名 </p></td>
    <td width="132" valign="top"><p align="center">顺义区 </p></td>
    <td width="96" valign="top"><p align="center">24 </p></td>
    <td width="177" valign="top"><p align="center">5 </p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第六名 </p></td>
    <td width="132" valign="top"><p align="center">房山区 </p></td>
    <td width="96" valign="top"><p align="center">24 </p></td>
    <td width="177" valign="top"><p align="center"><strong>7</strong> </p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第七名 </p></td>
    <td width="132" valign="top"><p align="center">怀柔区 </p></td>
    <td width="96" valign="top"><p align="center">32 </p></td>
    <td width="177" valign="top"><p align="center">12 </p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第八名 </p></td>
    <td width="132" valign="top"><p align="center">通州区 </p></td>
    <td width="96" valign="top"><p align="center">32 </p></td>
    <td width="177" valign="top"><p align="center">14 </p></td>
  </tr>
  <tr>
    <td width="55" rowspan="4"><p align="center"><strong>女</strong> <br />
            <strong>子</strong> <br />
            <strong>组</strong> </p></td>
    <td width="108" valign="top"><p align="center">第一名 </p></td>
    <td width="132" valign="top"><p align="center">门头沟区 </p></td>
    <td width="96" valign="top"><p align="center">7 </p></td>
    <td width="177" valign="top"><p align="center">2 </p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第二名 </p></td>
    <td width="132" valign="top"><p align="center">朝阳区 </p></td>
    <td width="96" valign="top"><p align="center">7 </p></td>
    <td width="177" valign="top"><p align="center">3 </p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第三名 </p></td>
    <td width="132" valign="top"><p align="center">昌平区 </p></td>
    <td width="96" valign="top"><p align="center">8 </p></td>
    <td width="177" valign="top"><p align="center">&nbsp;</p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第四名 </p></td>
    <td width="132" valign="top"><p align="center">延庆县 </p></td>
    <td width="96" valign="top"><p align="center">14 </p></td>
    <td width="177" valign="top"><p align="center">&nbsp;</p></td>
  </tr>
</table>
</body>
</html>
