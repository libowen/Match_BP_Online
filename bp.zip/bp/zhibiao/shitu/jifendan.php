<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>记分单_横式==示例</title>


<link href="/bp/css/shuchu.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
}
-->
</style>


</head>

<body>
<!--记分单_列表_A4-->
	<table style="font-weight:bold" border="1" cellspacing="0" cellpadding="0">
		 <tr>
		   <td>
				<table width="660px" border="0" cellspacing="0" cellpadding="0" style="font-size:14px"><!-- 记分单_横式-->
				   <tr>
					<td colspan="3" height="5px"></td>
				  </tr>
				   <tr>
					<td colspan="3">
					    ★&nbsp;计分单_横式&nbsp;★
					</td>
				   </tr>
				   <tr>
					<td colspan="3" height="5px"></td>
				  </tr>
				   <tr>
					<td width="36%">
						组别：					
				    </td>
					<td width="24%">&nbsp;
					    
					</td>
					<td width="40%">
				      日期：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;年&nbsp;&nbsp;&nbsp;&nbsp;月&nbsp;&nbsp;&nbsp;&nbsp;日 </td>
				  </tr>
				   <tr>
					<td colspan="3" height="5px"></td>
				  </tr>
				   <tr>
					<td colspan="3" height="5px">
				 	   <table class="jifendanHS" align="center" width="100%" border="1" cellspacing="0" cellpadding="0">
						  <tr>
							<td width="24">台<br />次</td>
							<td width="32">序号</td>
							<td width="110">姓名</td>
							<td width="50">先后</td>
							<td width="60">成绩</td>
							<td width="140">用时</td>
							<td width="45">犯规</td>
							<td width="auto">备注</td>
						  </tr>
						  <tr>
							<td rowspan="2">&nbsp;</td>
							<td height="26px">12</td>
							<td>附近的上课</td>
							<td>红方</td>
							<td>胜</td>
							<td>20分30秒10小时</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						  </tr>
						  <tr>
							<td height="26px">43</td>
							<td>大哥哥法国格</td>
							<td>黑方</td>
							<td>和</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						  </tr>
				 	   </table>
				    </td>
				  </tr>
				   <tr>
					<td colspan="3" height="5px"></td>
				  </tr>
				   <tr><!--尾部-->
					<td height="28px">  
					签字：红方：
					</td>  
					<td>
					  黑方： </td>
					<td>
					&nbsp;&nbsp;裁判员： </td>
				  </tr>
				   <tr><!-- 尾部-->
					<td colspan="3" height="5px"></td>
				  </tr>
				</table>   <!-- 记分单_横式-->
		  </td>
		 </tr>
		 <tr>
		   <td>
				<table width="660px" border="0" cellspacing="0" cellpadding="0" style="font-size:14px"><!-- 记分单_横式-->
				   <tr>
					<td colspan="3" height="5px"></td>
				  </tr>
				   <tr>
					<td colspan="3">
					    ★&nbsp;计分单_横式&nbsp;★
					</td>
				   </tr>
				   <tr>
					<td colspan="3" height="5px"></td>
				  </tr>
				   <tr>
					<td width="36%">
						组别：					
				    </td>
					<td width="24%">&nbsp;
					    
					</td>
					<td width="40%">
				      日期：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;年&nbsp;&nbsp;&nbsp;&nbsp;月&nbsp;&nbsp;&nbsp;&nbsp;日 </td>
				  </tr>
				   <tr>
					<td colspan="3" height="5px"></td>
				  </tr>
				   <tr>
					<td colspan="3" height="5px">
				 	   <table class="jifendanHS" align="center" width="100%" border="1" cellspacing="0" cellpadding="0">
						  <tr>
							<td width="24">台<br />次</td>
							<td width="32">序号</td>
							<td width="110">姓名</td>
							<td width="50">先后</td>
							<td width="60">成绩</td>
							<td width="140">用时</td>
							<td width="45">犯规</td>
							<td width="auto">备注</td>
						  </tr>
						  <tr>
							<td rowspan="2">&nbsp;</td>
							<td height="26px">12</td>
							<td>附近的上课</td>
							<td>红方</td>
							<td>胜</td>
							<td>20分30秒10小时</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						  </tr>
						  <tr>
							<td height="26px">43</td>
							<td>大哥哥法国格</td>
							<td>黑方</td>
							<td>和</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						  </tr>
				 	   </table>
				    </td>
				  </tr>
				   <tr>
					<td colspan="3" height="5px"></td>
				  </tr>
				   <tr><!--尾部-->
					<td height="28px">  
					签字：红方：
					</td>  
					<td>
					  黑方： </td>
					<td>
					&nbsp;&nbsp;裁判员： </td>
				  </tr>
				   <tr><!-- 尾部-->
					<td colspan="3" height="5px"></td>
				  </tr>
				</table>   <!-- 记分单_横式-->
		  </td>
		 </tr>
		 <tr>
		   <td>
				<table width="660px" border="0" cellspacing="0" cellpadding="0" style="font-size:14px"><!-- 记分单_横式-->
				   <tr>
					<td colspan="3" height="5px"></td>
				  </tr>
				   <tr>
					<td colspan="3">
					    ★&nbsp;计分单_横式&nbsp;★
					</td>
				   </tr>
				   <tr>
					<td colspan="3" height="5px"></td>
				  </tr>
				   <tr>
					<td width="36%">
						组别：					
				    </td>
					<td width="24%">&nbsp;
					    
					</td>
					<td width="40%">
				      日期：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;年&nbsp;&nbsp;&nbsp;&nbsp;月&nbsp;&nbsp;&nbsp;&nbsp;日 </td>
				  </tr>
				   <tr>
					<td colspan="3" height="5px"></td>
				  </tr>
				   <tr>
					<td colspan="3" height="5px">
				 	   <table class="jifendanHS" align="center" width="100%" border="1" cellspacing="0" cellpadding="0">
						  <tr>
							<td width="24">台<br />次</td>
							<td width="32">序号</td>
							<td width="110">姓名</td>
							<td width="50">先后</td>
							<td width="60">成绩</td>
							<td width="140">用时</td>
							<td width="45">犯规</td>
							<td width="auto">备注</td>
						  </tr>
						  <tr>
							<td rowspan="2">&nbsp;</td>
							<td height="26px">12</td>
							<td>附近的上课</td>
							<td>红方</td>
							<td>胜</td>
							<td>20分30秒10小时</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						  </tr>
						  <tr>
							<td height="26px">43</td>
							<td>大哥哥法国格</td>
							<td>黑方</td>
							<td>和</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						  </tr>
				 	   </table>
				    </td>
				  </tr>
				   <tr>
					<td colspan="3" height="5px"></td>
				  </tr>
				   <tr><!--尾部-->
					<td height="28px">  
					签字：红方：
					</td>  
					<td>
					  黑方： </td>
					<td>
					&nbsp;&nbsp;裁判员： </td>
				  </tr>
				   <tr><!-- 尾部-->
					<td colspan="3" height="5px"></td>
				  </tr>
				</table>   <!-- 记分单_横式-->
		  </td>
		 </tr>
		 <tr>
		   <td>
				<table width="660px" border="0" cellspacing="0" cellpadding="0" style="font-size:14px"><!-- 记分单_横式-->
				   <tr>
					<td colspan="3" height="5px"></td>
				  </tr>
				   <tr>
					<td colspan="3">
					    ★&nbsp;计分单_横式&nbsp;★
					</td>
				   </tr>
				   <tr>
					<td colspan="3" height="5px"></td>
				  </tr>
				   <tr>
					<td width="36%">
						组别：					
				    </td>
					<td width="24%">&nbsp;
					    
					</td>
					<td width="40%">
				      日期：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;年&nbsp;&nbsp;&nbsp;&nbsp;月&nbsp;&nbsp;&nbsp;&nbsp;日 </td>
				  </tr>
				   <tr>
					<td colspan="3" height="5px"></td>
				  </tr>
				   <tr>
					<td colspan="3" height="5px">
				 	   <table class="jifendanHS" align="center" width="100%" border="1" cellspacing="0" cellpadding="0">
						  <tr>
							<td width="24">台<br />次</td>
							<td width="32">序号</td>
							<td width="110">姓名</td>
							<td width="50">先后</td>
							<td width="60">成绩</td>
							<td width="140">用时</td>
							<td width="45">犯规</td>
							<td width="auto">备注</td>
						  </tr>
						  <tr>
							<td rowspan="2">&nbsp;</td>
							<td height="26px">12</td>
							<td>附近的上课</td>
							<td>红方</td>
							<td>胜</td>
							<td>20分30秒10小时</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						  </tr>
						  <tr>
							<td height="26px">43</td>
							<td>大哥哥法国格</td>
							<td>黑方</td>
							<td>和</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						  </tr>
				 	   </table>
				    </td>
				  </tr>
				   <tr>
					<td colspan="3" height="5px"></td>
				  </tr>
				   <tr><!--尾部-->
					<td height="28px">  
					签字：红方：
					</td>  
					<td>
					  黑方： </td>
					<td>
					&nbsp;&nbsp;裁判员： </td>
				  </tr>
				   <tr><!-- 尾部-->
					<td colspan="3" height="5px"></td>
				  </tr>
				</table>   <!-- 记分单_横式-->
		  </td>
		 </tr>
		 <tr>
		   <td>
				<table width="660px" border="0" cellspacing="0" cellpadding="0" style="font-size:14px"><!-- 记分单_横式-->
				   <tr>
					<td colspan="3" height="5px"></td>
				  </tr>
				   <tr>
					<td colspan="3">
					    ★&nbsp;计分单_横式&nbsp;★
					</td>
				   </tr>
				   <tr>
					<td colspan="3" height="5px"></td>
				  </tr>
				   <tr>
					<td width="36%">
						组别：					
				    </td>
					<td width="24%">&nbsp;
					    
					</td>
					<td width="40%">
				      日期：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;年&nbsp;&nbsp;&nbsp;&nbsp;月&nbsp;&nbsp;&nbsp;&nbsp;日 </td>
				  </tr>
				   <tr>
					<td colspan="3" height="5px"></td>
				  </tr>
				   <tr>
					<td colspan="3" height="5px">
				 	   <table class="jifendanHS" align="center" width="100%" border="1" cellspacing="0" cellpadding="0">
						  <tr>
							<td width="24">台<br />次</td>
							<td width="32">序号</td>
							<td width="110">姓名</td>
							<td width="50">先后</td>
							<td width="60">成绩</td>
							<td width="140">用时</td>
							<td width="45">犯规</td>
							<td width="auto">备注</td>
						  </tr>
						  <tr>
							<td rowspan="2">&nbsp;</td>
							<td height="26px">12</td>
							<td>附近的上课</td>
							<td>红方</td>
							<td>胜</td>
							<td>20分30秒10小时</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						  </tr>
						  <tr>
							<td height="26px">43</td>
							<td>大哥哥法国格</td>
							<td>黑方</td>
							<td>和</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						  </tr>
				 	   </table>
				    </td>
				  </tr>
				   <tr>
					<td colspan="3" height="5px"></td>
				  </tr>
				   <tr><!--尾部-->
					<td height="28px">  
					签字：红方：
					</td>  
					<td>
					  黑方： </td>
					<td>
					&nbsp;&nbsp;裁判员： </td>
				  </tr>
				   <tr><!-- 尾部-->
					<td colspan="3" height="5px"></td>
				  </tr>
				</table>   <!-- 记分单_横式-->
		  </td>
		 </tr>
	</table>


</body>
</html>
