<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>无标题文档</title>
</head>

<body>
<p align="center"><strong>象棋赛个人成绩</strong> </p>
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="55" valign="top"><p align="center"><strong>组别</strong> </p></td>
    <td width="108"><p align="center"><strong>名次</strong> </p></td>
    <td width="108"><p align="center"><strong>姓名</strong> </p></td>
    <td width="120"><p align="center"><strong>单位</strong> </p></td>
    <td width="88"><p align="center"><strong>积分</strong> </p></td>
    <td width="88"><p align="center"><strong>对手分</strong> </p></td>
  </tr>
  <tr>
    <td width="55" rowspan="8"><p align="center"><strong>男</strong> <br />
            <strong>子</strong> <br />
            <strong>组</strong> </p></td>
    <td width="108" valign="top"><p align="center">第一名 </p></td>
    <td width="108" valign="top"><p align="center">陈启明 </p></td>
    <td width="120" valign="top"><p align="center">门头沟区 </p></td>
    <td width="88" valign="top"><p align="center">11 </p></td>
    <td width="88" valign="top"><p align="center">&nbsp;</p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第二名 </p></td>
    <td width="108" valign="top"><p align="center">魏国同 </p></td>
    <td width="120" valign="top"><p align="center">昌平区 </p></td>
    <td width="88" valign="top"><p align="center"><strong>10</strong> </p></td>
    <td width="88" valign="top"><p align="center"><strong>65</strong> </p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第三名 </p></td>
    <td width="108" valign="top"><p align="center">宋国强 </p></td>
    <td width="120" valign="top"><p align="center">门头沟区 </p></td>
    <td width="88" valign="top"><p align="center">10 </p></td>
    <td width="88" valign="top"><p align="center">58 </p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第四名 </p></td>
    <td width="108" valign="top"><p align="center">张一男 </p></td>
    <td width="120" valign="top"><p align="center">朝阳区 </p></td>
    <td width="88" valign="top"><p align="center">10 </p></td>
    <td width="88" valign="top"><p align="center">49 </p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第五名 </p></td>
    <td width="108" valign="top"><p align="center">唐文祥 </p></td>
    <td width="120" valign="top"><p align="center">顺义区 </p></td>
    <td width="88" valign="top"><p align="center"><strong>9</strong> </p></td>
    <td width="88" valign="top"><p align="center"><strong>61</strong> </p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第六名 </p></td>
    <td width="108" valign="top"><p align="center">马&nbsp; 维 </p></td>
    <td width="120" valign="top"><p align="center">朝阳区 </p></td>
    <td width="88" valign="top"><p align="center"><strong>9</strong> </p></td>
    <td width="88" valign="top"><p align="center"><strong>52</strong> </p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第七名 </p></td>
    <td width="108" valign="top"><p align="center">于&nbsp; 川 </p></td>
    <td width="120" valign="top"><p align="center">房山区 </p></td>
    <td width="88" valign="top"><p align="center"><strong>9</strong> </p></td>
    <td width="88" valign="top"><p align="center"><strong>50</strong> </p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第八名 </p></td>
    <td width="108" valign="top"><p align="center">张鹏 </p></td>
    <td width="120" valign="top"><p align="center">海淀区 </p></td>
    <td width="88" valign="top"><p align="center"><strong>9</strong> </p></td>
    <td width="88" valign="top"><p align="center"><strong>48</strong> </p></td>
  </tr>
  <tr>
    <td width="55" rowspan="8"><p align="center"><strong>女</strong> <br />
            <strong>子</strong> <br />
            <strong>组</strong> </p></td>
    <td width="108" valign="top"><p align="center">第一名 </p></td>
    <td width="108" valign="top"><p align="center">唐&nbsp; 丹 </p></td>
    <td width="120" valign="top"><p align="center">昌平区 </p></td>
    <td width="88" valign="top"><p align="center"><strong>11</strong> </p></td>
    <td width="88" valign="top"><p align="center"><strong>32</strong><strong>．5</strong> </p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第二名 </p></td>
    <td width="108" valign="top"><p align="center">张&nbsp; 梅 </p></td>
    <td width="120" valign="top"><p align="center">门头沟区 </p></td>
    <td width="88" valign="top"><p align="center"><strong>11</strong> </p></td>
    <td width="88" valign="top"><p align="center"><strong>26</strong><strong>．5</strong> </p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第三名 </p></td>
    <td width="108" valign="top"><p align="center">李&nbsp; 冉 </p></td>
    <td width="120" valign="top"><p align="center">朝阳区 </p></td>
    <td width="88" valign="top"><p align="center"><strong>8</strong> </p></td>
    <td width="88" valign="top"><p align="center"><strong>&nbsp;</strong> </p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第四名 </p></td>
    <td width="108" valign="top"><p align="center">赵爱荣 </p></td>
    <td width="120" valign="top"><p align="center">朝阳区 </p></td>
    <td width="88" valign="top"><p align="center"><strong>7</strong> </p></td>
    <td width="88" valign="top"><p align="center"><strong>17</strong><strong>．5</strong> </p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第五名 </p></td>
    <td width="108" valign="top"><p align="center">刚秋英 </p></td>
    <td width="120" valign="top"><p align="center">门头沟区 </p></td>
    <td width="88" valign="top"><p align="center"><strong>7</strong> </p></td>
    <td width="88" valign="top"><p align="center"><strong>12</strong><strong>．5</strong> </p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第六名 </p></td>
    <td width="108" valign="top"><p align="center">武爱平 </p></td>
    <td width="120" valign="top"><p align="center">延庆县 </p></td>
    <td width="88" valign="top"><p align="center"><strong>4</strong> </p></td>
    <td width="88" valign="top"><p align="center"><strong>&nbsp;</strong> </p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第七名 </p></td>
    <td width="108" valign="top"><p align="center">梁鸿雁 </p></td>
    <td width="120" valign="top"><p align="center">昌平区 </p></td>
    <td width="88" valign="top"><p align="center"><strong>2</strong> </p></td>
    <td width="88" valign="top"><p align="center"><strong>&nbsp;</strong> </p></td>
  </tr>
  <tr>
    <td width="108" valign="top"><p align="center">第八名 </p></td>
    <td width="108" valign="top"><p align="center">王亚惠 </p></td>
    <td width="120" valign="top"><p align="center">延庆县 </p></td>
    <td width="88" valign="top"><p align="center"><strong>0</strong> </p></td>
    <td width="88" valign="top"><p align="center"><strong>&nbsp;</strong> </p></td>
  </tr>
</table>
<p align="left"><strong>&nbsp; </strong></p>
</body>
</html>
