<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>记分单_简式==示例 每页A4纸可容4行8台16人</title>


<link href="/bp/css/shuchu.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
}
-->
</style>


</head>

<body>
<!--记分单_列表_A4-->
	<table border="0" style="font-weight:bold" cellspacing="0" cellpadding="0">
		  <tr><!-- 记分单_简式-->
			<td colspan="3" height="1px"></td>
		  </tr>

		  <tr>
			<td width="327px">
			   <table class="jifendanHS" align="center" width="330px" border="1" cellspacing="0" cellpadding="0">
				  <tr>
					<td height="38px" colspan="4">
					《&nbsp;男子A组_计分单&nbsp;》<br />
					台次:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;第&nbsp;&nbsp;&nbsp;轮					</td>
				 </tr>
				  <tr>
					<td width="45" height="24">&nbsp;</td>
					<td width="140">红&nbsp;&nbsp;方</td>
					<td width="2">&nbsp;</td>
					<td width="140">黑&nbsp;&nbsp;方</td>
				  </tr>
				  <tr>
					<td height="26">姓名</td>
					<td>[9]大哥哥法国格</td>
					<td>&nbsp;</td>
					<td>[256]大大幅度国格</td>
				  </tr>
				  <tr>
					<td height="26">用时</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
					<td>&nbsp;</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
				 </tr>
				  <tr>
					<td height="30">签名</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				 </tr>
				  <tr>
					<td height="30">结果</td>
					<td colspan="3">&nbsp;</td>
				 </tr>
										  <tr>
					<td>裁判<br />签名</td>
					<td>&nbsp;</td>
					<td colspan="2">&nbsp;&nbsp;月&nbsp;&nbsp;日&nbsp;&nbsp;时&nbsp;&nbsp;分</td>
				 </tr>
			 </table>				    
			</td>
			<td width="auto">
			</td>
			<td width="327px">
			   <table class="jifendanHS" align="center" width="330px" border="1" cellspacing="0" cellpadding="0">
				  <tr>
					<td height="38px" colspan="4">
					《&nbsp;男子A组_计分单&nbsp;》<br />
					台次:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;第&nbsp;&nbsp;&nbsp;轮					</td>
				 </tr>
				  <tr>
					<td width="45" height="24">&nbsp;</td>
					<td width="140">红&nbsp;&nbsp;方</td>
					<td width="2">&nbsp;</td>
					<td width="140">黑&nbsp;&nbsp;方</td>
				  </tr>
				  <tr>
					<td height="26">姓名</td>
					<td>[9]大哥哥法国格</td>
					<td>&nbsp;</td>
					<td>[256]大大幅度国格</td>
				  </tr>
				  <tr>
					<td height="26">用时</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
					<td>&nbsp;</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
				 </tr>
				  <tr>
					<td height="30">签名</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				 </tr>
				  <tr>
					<td height="30">结果</td>
					<td colspan="3">&nbsp;</td>
				 </tr>
										  <tr>
					<td>裁判<br />签名</td>
					<td>&nbsp;</td>
					<td colspan="2">&nbsp;&nbsp;月&nbsp;&nbsp;日&nbsp;&nbsp;时&nbsp;&nbsp;分</td>
				 </tr>
			 </table>					    
		  </td>
		 </tr><!-- 记分单_简式-->
		  <tr>
			<td colspan="3" height="1px"></td>
		  </tr>
		  <tr>
			<td width="327px">
			   <table class="jifendanHS" align="center" width="330px" border="1" cellspacing="0" cellpadding="0">
				  <tr>
					<td height="38px" colspan="4">
					《&nbsp;男子A组_计分单&nbsp;》<br />
					台次:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;第&nbsp;&nbsp;&nbsp;轮					</td>
				 </tr>
				  <tr>
					<td width="45" height="24">&nbsp;</td>
					<td width="140">红&nbsp;&nbsp;方</td>
					<td width="2">&nbsp;</td>
					<td width="140">黑&nbsp;&nbsp;方</td>
				  </tr>
				  <tr>
					<td height="26">姓名</td>
					<td>[9]大哥哥法国格</td>
					<td>&nbsp;</td>
					<td>[256]大大幅度国格</td>
				  </tr>
				  <tr>
					<td height="26">用时</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
					<td>&nbsp;</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
				 </tr>
				  <tr>
					<td height="30">签名</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				 </tr>
				  <tr>
					<td height="30">结果</td>
					<td colspan="3">&nbsp;</td>
				 </tr>
										  <tr>
					<td>裁判<br />签名</td>
					<td>&nbsp;</td>
					<td colspan="2">&nbsp;&nbsp;月&nbsp;&nbsp;日&nbsp;&nbsp;时&nbsp;&nbsp;分</td>
				 </tr>
			 </table>				    
			</td>
			<td width="auto">
			</td>
			<td width="327px">
			   <table class="jifendanHS" align="center" width="330px" border="1" cellspacing="0" cellpadding="0">
				  <tr>
					<td height="38px" colspan="4">
					《&nbsp;男子A组_计分单&nbsp;》<br />
					台次:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;第&nbsp;&nbsp;&nbsp;轮					</td>
				 </tr>
				  <tr>
					<td width="45" height="24">&nbsp;</td>
					<td width="140">红&nbsp;&nbsp;方</td>
					<td width="2">&nbsp;</td>
					<td width="140">黑&nbsp;&nbsp;方</td>
				  </tr>
				  <tr>
					<td height="26">姓名</td>
					<td>[9]大哥哥法国格</td>
					<td>&nbsp;</td>
					<td>[256]大大幅度国格</td>
				  </tr>
				  <tr>
					<td height="26">用时</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
					<td>&nbsp;</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
				 </tr>
				  <tr>
					<td height="30">签名</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				 </tr>
				  <tr>
					<td height="30">结果</td>
					<td colspan="3">&nbsp;</td>
				 </tr>
										  <tr>
					<td>裁判<br />签名</td>
					<td>&nbsp;</td>
					<td colspan="2">&nbsp;&nbsp;月&nbsp;&nbsp;日&nbsp;&nbsp;时&nbsp;&nbsp;分</td>
				 </tr>
			 </table>					    
		  </td>
		 </tr><!-- 记分单_简式-->
		  <tr>
			<td colspan="3" height="1px"></td>
		  </tr>
		  <tr>
			<td width="327px">
			   <table class="jifendanHS" align="center" width="330px" border="1" cellspacing="0" cellpadding="0">
				  <tr>
					<td height="38px" colspan="4">
					《&nbsp;男子A组_计分单&nbsp;》<br />
					台次:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;第&nbsp;&nbsp;&nbsp;轮					</td>
				 </tr>
				  <tr>
					<td width="45" height="24">&nbsp;</td>
					<td width="140">红&nbsp;&nbsp;方</td>
					<td width="2">&nbsp;</td>
					<td width="140">黑&nbsp;&nbsp;方</td>
				  </tr>
				  <tr>
					<td height="26">姓名</td>
					<td>[9]大哥哥法国格</td>
					<td>&nbsp;</td>
					<td>[256]大大幅度国格</td>
				  </tr>
				  <tr>
					<td height="26">用时</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
					<td>&nbsp;</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
				 </tr>
				  <tr>
					<td height="30">签名</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				 </tr>
				  <tr>
					<td height="30">结果</td>
					<td colspan="3">&nbsp;</td>
				 </tr>
										  <tr>
					<td>裁判<br />签名</td>
					<td>&nbsp;</td>
					<td colspan="2">&nbsp;&nbsp;月&nbsp;&nbsp;日&nbsp;&nbsp;时&nbsp;&nbsp;分</td>
				 </tr>
			 </table>				    
			</td>
			<td width="auto">
			</td>
			<td width="327px">
			   <table class="jifendanHS" align="center" width="330px" border="1" cellspacing="0" cellpadding="0">
				  <tr>
					<td height="38px" colspan="4">
					《&nbsp;男子A组_计分单&nbsp;》<br />
					台次:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;第&nbsp;&nbsp;&nbsp;轮					</td>
				 </tr>
				  <tr>
					<td width="45" height="24">&nbsp;</td>
					<td width="140">红&nbsp;&nbsp;方</td>
					<td width="2">&nbsp;</td>
					<td width="140">黑&nbsp;&nbsp;方</td>
				  </tr>
				  <tr>
					<td height="26">姓名</td>
					<td>[9]大哥哥法国格</td>
					<td>&nbsp;</td>
					<td>[256]大大幅度国格</td>
				  </tr>
				  <tr>
					<td height="26">用时</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
					<td>&nbsp;</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
				 </tr>
				  <tr>
					<td height="30">签名</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				 </tr>
				  <tr>
					<td height="30">结果</td>
					<td colspan="3">&nbsp;</td>
				 </tr>
										  <tr>
					<td>裁判<br />签名</td>
					<td>&nbsp;</td>
					<td colspan="2">&nbsp;&nbsp;月&nbsp;&nbsp;日&nbsp;&nbsp;时&nbsp;&nbsp;分</td>
				 </tr>
			 </table>					    
		  </td>
		 </tr><!-- 记分单_简式-->
		  <tr>
			<td colspan="3" height="1px"></td>
		  </tr>
	</table>

>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
<!--记分单_列表_A4=注意 下面只能布A4纸3行半-->
	<table border="0" style="font-weight:bold" cellspacing="0" cellpadding="0">
<!--		  <tr>
			<td colspan="3" height="2px"></td>
		  </tr>-->
		  <tr>
			<td width="328px">
			   <table class="jifendanHS" align="center" width="330px" border="1" cellspacing="0" cellpadding="0">
				  <tr>
					<td height="26" colspan="4">
					<br />
					《&nbsp;男子A组_计分单&nbsp;》<br />
					台次&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;第___轮</td>
				 </tr>
				  <tr>
					<td width="45" height="26">&nbsp;</td>
					<td width="140">红&nbsp;&nbsp;方</td>
					<td width="3">&nbsp;</td>
					<td width="140">黑&nbsp;&nbsp;方</td>
				  </tr>
				  <tr>
					<td height="26">序号</td>
					<td>12</td>
					<td>&nbsp;</td>
					<td>34</td>
				  </tr>
				  <tr>
					<td height="26">姓名</td>
					<td>大哥哥法国格</td>
					<td>&nbsp;</td>
					<td>大大幅度国格</td>
				  </tr>
				  <tr>
					<td height="26">用时</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
					<td>&nbsp;</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
				 </tr>
				  <tr>
					<td height="32">签名</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				 </tr>
				  <tr>
					<td height="32">结果</td>
					<td colspan="3">&nbsp;</td>
				 </tr>
										  <tr>
					<td>裁判<br />签名</td>
					<td>&nbsp;</td>
					<td colspan="2">&nbsp;&nbsp;月&nbsp;&nbsp;日&nbsp;&nbsp;时&nbsp;&nbsp;分</td>
				 </tr>
			 </table>				    
			</td>
			<td width="auto">
			</td>
			<td width="328px">
			   <table class="jifendanHS" align="center" width="330px" border="1" cellspacing="0" cellpadding="0">
				  <tr>
					<td height="26" colspan="4">
					<br />
					《&nbsp;男子A组_计分单&nbsp;》<br />
					台次&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;第___轮</td>
				 </tr>
				  <tr>
					<td width="45" height="26">&nbsp;</td>
					<td width="140">红&nbsp;&nbsp;方</td>
					<td width="3">&nbsp;</td>
					<td width="140">黑&nbsp;&nbsp;方</td>
				  </tr>
				  <tr>
					<td height="26">序号</td>
					<td>12</td>
					<td>&nbsp;</td>
					<td>34</td>
				  </tr>
				  <tr>
					<td height="26">姓名</td>
					<td>大哥哥法国格</td>
					<td>&nbsp;</td>
					<td>大大幅度国格</td>
				  </tr>
				  <tr>
					<td height="26">用时</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
					<td>&nbsp;</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
				 </tr>
				  <tr>
					<td height="32">签名</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				 </tr>
				  <tr>
					<td height="32">结果</td>
					<td colspan="3">&nbsp;</td>
				 </tr>
										  <tr>
					<td>裁判<br />签名</td>
					<td>&nbsp;</td>
					<td colspan="2">&nbsp;&nbsp;月&nbsp;&nbsp;日&nbsp;&nbsp;时&nbsp;&nbsp;分</td>
				 </tr>
			 </table>				    
		<!-- 记分单_简式-->
		  </td>
		 </tr>
		  <tr>
			<td colspan="3" height="2px"></td>
		  </tr>


		  <tr>
			<td width="328px">
			   <table class="jifendanHS" align="center" width="330px" border="1" cellspacing="0" cellpadding="0">
				  <tr>
					<td height="26" colspan="4">
					<br />
					《&nbsp;男子A组_计分单&nbsp;》<br />
					台次&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;第___轮</td>
				 </tr>
				  <tr>
					<td width="45" height="26">&nbsp;</td>
					<td width="140">红&nbsp;&nbsp;方</td>
					<td width="3">&nbsp;</td>
					<td width="140">黑&nbsp;&nbsp;方</td>
				  </tr>
				  <tr>
					<td height="26">序号</td>
					<td>12</td>
					<td>&nbsp;</td>
					<td>34</td>
				  </tr>
				  <tr>
					<td height="26">姓名</td>
					<td>大哥哥法国格</td>
					<td>&nbsp;</td>
					<td>大大幅度国格</td>
				  </tr>
				  <tr>
					<td height="26">用时</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
					<td>&nbsp;</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
				 </tr>
				  <tr>
					<td height="32">签名</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				 </tr>
				  <tr>
					<td height="32">结果</td>
					<td colspan="3">&nbsp;</td>
				 </tr>
										  <tr>
					<td>裁判<br />签名</td>
					<td>&nbsp;</td>
					<td colspan="2">&nbsp;&nbsp;月&nbsp;&nbsp;日&nbsp;&nbsp;时&nbsp;&nbsp;分</td>
				 </tr>
			 </table>				    
			</td>
			<td width="auto">
			</td>
			<td width="328px">
			   <table class="jifendanHS" align="center" width="330px" border="1" cellspacing="0" cellpadding="0">
				  <tr>
					<td height="26" colspan="4">
					<br />
					《&nbsp;男子A组_计分单&nbsp;》<br />
					台次&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;第___轮</td>
				 </tr>
				  <tr>
					<td width="45" height="26">&nbsp;</td>
					<td width="140">红&nbsp;&nbsp;方</td>
					<td width="3">&nbsp;</td>
					<td width="140">黑&nbsp;&nbsp;方</td>
				  </tr>
				  <tr>
					<td height="26">序号</td>
					<td>12</td>
					<td>&nbsp;</td>
					<td>34</td>
				  </tr>
				  <tr>
					<td height="26">姓名</td>
					<td>大哥哥法国格</td>
					<td>&nbsp;</td>
					<td>大大幅度国格</td>
				  </tr>
				  <tr>
					<td height="26">用时</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
					<td>&nbsp;</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
				 </tr>
				  <tr>
					<td height="32">签名</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				 </tr>
				  <tr>
					<td height="32">结果</td>
					<td colspan="3">&nbsp;</td>
				 </tr>
										  <tr>
					<td>裁判<br />签名</td>
					<td>&nbsp;</td>
					<td colspan="2">&nbsp;&nbsp;月&nbsp;&nbsp;日&nbsp;&nbsp;时&nbsp;&nbsp;分</td>
				 </tr>
			 </table>				    
		<!-- 记分单_简式-->
		  </td>
		 </tr>
		  <tr>
			<td colspan="3" height="2px"></td>
		  </tr>

		  <tr>
			<td width="328px">
			   <table class="jifendanHS" align="center" width="330px" border="1" cellspacing="0" cellpadding="0">
				  <tr>
					<td height="26" colspan="4">
					<br />
					《&nbsp;男子A组_计分单&nbsp;》<br />
					台次&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;第___轮</td>
				 </tr>
				  <tr>
					<td width="45" height="26">&nbsp;</td>
					<td width="140">红&nbsp;&nbsp;方</td>
					<td width="3">&nbsp;</td>
					<td width="140">黑&nbsp;&nbsp;方</td>
				  </tr>
				  <tr>
					<td height="26">序号</td>
					<td>12</td>
					<td>&nbsp;</td>
					<td>34</td>
				  </tr>
				  <tr>
					<td height="26">姓名</td>
					<td>大哥哥法国格</td>
					<td>&nbsp;</td>
					<td>大大幅度国格</td>
				  </tr>
				  <tr>
					<td height="26">用时</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
					<td>&nbsp;</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
				 </tr>
				  <tr>
					<td height="32">签名</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				 </tr>
				  <tr>
					<td height="32">结果</td>
					<td colspan="3">&nbsp;</td>
				 </tr>
										  <tr>
					<td>裁判<br />签名</td>
					<td>&nbsp;</td>
					<td colspan="2">&nbsp;&nbsp;月&nbsp;&nbsp;日&nbsp;&nbsp;时&nbsp;&nbsp;分</td>
				 </tr>
			 </table>				    
			</td>
			<td width="auto">
			</td>
			<td width="328px">
			   <table class="jifendanHS" align="center" width="330px" border="1" cellspacing="0" cellpadding="0">
				  <tr>
					<td height="26" colspan="4">
					<br />
					《&nbsp;男子A组_计分单&nbsp;》<br />
					台次&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;第___轮</td>
				 </tr>
				  <tr>
					<td width="45" height="26">&nbsp;</td>
					<td width="140">红&nbsp;&nbsp;方</td>
					<td width="3">&nbsp;</td>
					<td width="140">黑&nbsp;&nbsp;方</td>
				  </tr>
				  <tr>
					<td height="26">序号</td>
					<td>12</td>
					<td>&nbsp;</td>
					<td>34</td>
				  </tr>
				  <tr>
					<td height="26">姓名</td>
					<td>大哥哥法国格</td>
					<td>&nbsp;</td>
					<td>大大幅度国格</td>
				  </tr>
				  <tr>
					<td height="26">用时</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
					<td>&nbsp;</td>
					<td>&nbsp;&nbsp;时&nbsp;&nbsp;&nbsp;分&nbsp;&nbsp;&nbsp;秒</td>
				 </tr>
				  <tr>
					<td height="32">签名</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
					<td>&nbsp;</td>
				 </tr>
				  <tr>
					<td height="32">结果</td>
					<td colspan="3">&nbsp;</td>
				 </tr>
										  <tr>
					<td>裁判<br />签名</td>
					<td>&nbsp;</td>
					<td colspan="2">&nbsp;&nbsp;月&nbsp;&nbsp;日&nbsp;&nbsp;时&nbsp;&nbsp;分</td>
				 </tr>
			 </table>				    
		<!-- 记分单_简式-->
		  </td>
		 </tr>
		  <tr>
			<td colspan="3" height="2px"></td>
		  </tr>
	</table>

</body>
</html>
