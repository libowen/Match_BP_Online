<?php
/**
* FILE_NAME : GRmc.php   FILE_PATH : F:\PHPnow\htdocs\bp\zhibiao\GRmc.php
* ....书写本页代码的说明
*
* @copyright Copyright (c) 2010
*/
session_start();
include("../config.inc.php");
require_once(INCLUDE_PATH."yanzheng.php");



include(ROOT_PATH."zhibiao/moban/A4.php");
?>