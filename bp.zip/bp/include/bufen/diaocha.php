
<?php
if ($diaochaid) {
	if (!diaocha) {
		
	}
}
?>
<tr> 
    <td height="200" colspan="3" align="center">           <!--在线调查列表 -->
		 <table width="197" border="0" cellspacing="0" cellpadding="0">
			<tr> 
			  <td><img src="/bp/image/diaocha.gif" width="197" height="22"></td>
			</tr>
			<tr> 
			  <td height="158" align="center" bgcolor="#FFFFFF">&nbsp; </td>
			</tr>
			<tr> 
			  <td><img src="/bp/image/twdesign_0046.gif" width="197" height="5"></td>
			</tr>
	  </table>
    </td>                                                <!--在线调查列表 -->
  </tr>  
<?php 
?>