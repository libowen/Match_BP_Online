<table width="988" border="0" align="center" cellpadding="0" cellspacing="0">
	<tr> 
			  
		<td width="8"><img src="/bp/image/twdesign_0016.gif" width="8" height="85"></td>
			  
		<td width="970" align="center" background="/bp/image/twdesign_0018.gif"><span class="China-12-FFFFFF-20">
		   <a href="http://ruyihe.com/bbs/" target="_blank" class="China-12-FFFFFF-20">交流论坛</a> 
		  | <a href="http://ruyice.com/demoblog/" target="_blank" class="China-12-FFFFFF-20">演示博客</a> 
		  | <a href="http://ruyihe.com/url-submit/" target="_blank" class="China-12-FFFFFF-20">关于我们</a> 
		  | <a href="http://ruyihe.com/feedback/" class="China-12-FFFFFF-20">合作联系</a> | <a href="#" target="_blank" class="China-12-FFFFFF-20">合作伙伴</a> 
		  | <a href="http://ruyihe.com/url-submit/" target="_blank" class="China-12-FFFFFF-20">友情链接</a> 
		  | <a href="http://ruyihe.com/feedback/" target="_blank" class="China-12-FFFFFF-20">意见反馈</a> 
		  | <a href="http://ruyihe.com/bbs/forum.php?gid=55" target="_blank" class="China-12-FFFFFF-20">帮助HELP</a><br>
		  <span class="China-12-FFFFFF-20">如意盒网络平台 版权所有 </span></span><span class="English-10-FFFFFF-20">Copyright 
		  @ 2010- </span><span class="China-12-FFFFFF-20"><span class="China-12-FFFFFF-20"> 
		   E-mail：</span><a href="mailto:ruyihe@126.com" target="_blank" class="English-10-FFFFFF-20">ruyihe@126.com</a><br>
		  <span class="China-12-FFFFFF-20">设计版本：</span></span><span class="English-10-FFFFFF-20">Match BP Online V2.3</span><span class="China-12-FFFFFF-20">
		  参赛版
		<script type="text/javascript"> var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
		document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F1b3c161953b2b3f01dab7a4d523176c6' type='text/javascript'%3E%3C/script%3E"));
		</script>
		+
		<script src="http://s13.cnzz.com/stat.php?id=2052676&web_id=2052676&show=pic1" language="JavaScript"></script>
            </td>
			  <td width="9"><img src="/bp/image/twdesign_0017.gif" width="9" height="85"></td>
	  </tr>
</table>
<div id="safeDiv">棋类比赛积分编排制</div>