<head>
<meta name="Keywords" content="积分编排,比赛编排,电脑积分编排,棋类">
<meta name="Description" content="免费在线棋类比赛积分编排程序系统，实现电脑积分编排，各式表格灵活输出，新增在线协同管理和查询储存等多种功能，比传统比赛编排软件更适合基层棋牌类积分编排制的比赛使用">
<meta name="Generator" content="LiBowen's HTML Generator  2.2版=2010年8月21日">
<meta http-equiv="content-Type" content="text/html; charset=UTF-8" />
<title><?php $title?print $title:print '无标题-比赛编排管理系统';?></title>
<link href="/bp/css/<?php $css?print $css:print 'default';?>.css" rel="stylesheet" type="text/css">
<script src="/bp/js/<?php $js?print $js:print 'default';?>.js" type="text/javascript" language="javascript"></script>
</head>