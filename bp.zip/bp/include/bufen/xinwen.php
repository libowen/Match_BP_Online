<tr valign="top"> 
    <td width="7" bgcolor="#D2D2D2"></td>
    <td height="auto"> <!--赛事新闻 -->
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td height="8"></td>
        </tr>
        <tr> 
          <td><a href="baoliuweizhi"><img src="/bp/image/saishixinwen.gif" width="197" height="22" border="0" usemap="#Map2MapMap"></a></td>
        </tr>

        <tr> 
          <td height="5" bgcolor="#FFFFFF"></td>
        </tr>
        <tr> 
          <td height="auto" valign="top" bgcolor="#FFFFFF">
          	  <table width="100%" cellpadding="0" cellspacing="0" >
          	  	<tr><td colspan="2" style="text-align:left"><img src="/bp/image/arrow2.gif" width=12 height=16>  <a href=http://www.designac.com/2005/4-19/09253554209.html target="_blank">Flash&nbsp;Film&nbsp;Festival&nbsp;2005&nbsp;获</a></td></tr>
          	  	<tr><td colspan="2" style="text-align:left"><img src="/bp/image/arrow2.gif" width=12 height=16>  <a href=http://www.designac.com/2005/4-19/0922022640.html target="_blank">阳光医院&nbsp;flash&nbsp;广告设计大赛</a></td></tr>
          	  	<tr><td colspan="2" style="text-align:left"><img src="/bp/image/arrow2.gif" width=12 height=16>  <a href=http://www.designac.com/2005/3-19/01422239212.html target="_blank">国际数字内容产业盛会第三届</a></td></tr>
          	  	<tr><td colspan="2" style="text-align:left"><img src="/bp/image/arrow2.gif" width=12 height=16>  <a href=http://www.designac.com/2005/3-14/09191696212.html target="_blank">ASLA2005年奖项参赛报名征集</a></td></tr>
          	  	<tr><td colspan="2" style="text-align:left"><img src="/bp/image/arrow2.gif" width=12 height=16>  <a href=http://www.designac.com/2005/3-10/09244425200.html target="_blank">上海:《波斯王子：武者之心》</a></td></tr>
          	 </table>
          </td>
        </tr>
        <tr> 
          <td height="5"><img src="/bp/image/twdesign_0046.gif" width="197" height="5"></td>
        </tr>
      </table>
    </td>                        <!--赛事新闻 -->
    <td width="7" bgcolor="#D2D2D2"></td>
  </tr>