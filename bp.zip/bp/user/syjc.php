<?php


header("Content-type: text/html; charset=utf-8");//暂时的
exit('<script>alert("正在收集、整理、汇总中。。。欢迎提供宝贵意见。返回原页面"); window.history.back();</script>');  
?>